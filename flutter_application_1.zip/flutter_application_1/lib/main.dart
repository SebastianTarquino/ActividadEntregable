import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: BottomNavBarExample(),
    );
  }
}

class BottomNavBarExample extends StatefulWidget {
  const BottomNavBarExample({super.key});

  @override
  State<BottomNavBarExample> createState() => _BottomNavBarExampleState();
}

class _BottomNavBarExampleState extends State<BottomNavBarExample> {
  int _selectedIndex = 0;
  bool showList = true;

 final List<Map<String, dynamic>> languages = [
    {"name": "Python", "image": "assets/images/python.png"},
    {"name": "Java", "image": "assets/images/java.png"},
    {"name": "Dart", "image": "assets/images/dart.png"},
    {"name": "JavaScript", "image": "assets/images/javascript.png"},
  ];

  static const List<Widget> _otherPages = <Widget>[
    Center(child: Text('Announcements Page', style: TextStyle(fontSize: 25))),
    Center(child: Text('Cart Page', style: TextStyle(fontSize: 25))),
    Center(child: Text('Notifications Page', style: TextStyle(fontSize: 25))),
    Center(child: Text('Profile Page', style: TextStyle(fontSize: 25))),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  // --- LISTA DE LENGUAJES ---
  Widget buildListView() {
    return ListView.builder(
      itemCount: languages.length,
      itemBuilder: (context, index) {
        return ListTile(
          leading: Image.asset(
            languages[index]["image"],
            width: 40,
            height: 40,
          ),
          title: Text(languages[index]["name"]),
        );
      },
    );
  }

  // --- CARDS DE LENGUAJES ---
  Widget buildCardView() {
    return GridView.builder(
      padding: const EdgeInsets.all(10),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, 
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
      ),
      itemCount: languages.length,
      itemBuilder: (context, index) {
        return Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          elevation: 5,
          color: const Color(0xFFF3E5F5),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                languages[index]["image"],
                width: 60,
                height: 60,
              ),
              const SizedBox(height: 10),
              Text(
                languages[index]["name"],
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    Widget currentBody;

    if (_selectedIndex == 0) {
      currentBody = showList ? buildListView() : buildCardView();
    } else {
      currentBody = _otherPages[_selectedIndex - 1];
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF7E57C2),
        title: Text(_selectedIndex == 0
            ? "Lenguajes de Programación"
            : "Bottom Navigation Example"),
        centerTitle: true,
        actions: _selectedIndex == 0
            ? [
                IconButton(
                  icon: const Icon(Icons.swap_horiz),
                  onPressed: () {
                    setState(() {
                      showList = !showList;
                    });
                  },
                ),
              ]
            : null,
      ),
      drawer: _selectedIndex == 0
          ? Drawer(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  const DrawerHeader(
                    decoration: BoxDecoration(color: Color(0xFF7E57C2)),
                    child: Text(
                      'Menú de Navegación',
                      style: TextStyle(color: Colors.white, fontSize: 20),
                    ),
                  ),
                  ListTile(
                    leading: const Icon(Icons.list),
                    title: const Text('Vista Lista'),
                    onTap: () {
                      setState(() {
                        showList = true;
                      });
                      Navigator.pop(context);
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.view_agenda),
                    title: const Text('Vista Cards'),
                    onTap: () {
                      setState(() {
                        showList = false;
                      });
                      Navigator.pop(context);
                    },
                  ),
                ],
              ),
            )
          : null,
      body: currentBody,
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: const Color(0xFF7E57C2),
        unselectedItemColor: Colors.black,
        showSelectedLabels: false,
        showUnselectedLabels: false,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            activeIcon: Icon(Icons.home, color: Color(0xFF7E57C2)),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.campaign_outlined),
            activeIcon: Icon(Icons.campaign, color: Color(0xFF7E57C2)),
            label: 'Announcements',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_cart_outlined),
            activeIcon: Icon(Icons.shopping_cart, color: Color(0xFF7E57C2)),
            label: 'Cart',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.notifications_none),
            activeIcon: Icon(Icons.notifications, color: Color(0xFF7E57C2)),
            label: 'Notifications',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            activeIcon: Icon(Icons.person, color: Color(0xFF7E57C2)),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
