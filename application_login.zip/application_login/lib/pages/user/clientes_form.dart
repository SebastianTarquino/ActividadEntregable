import 'package:flutter/material.dart';

class ClienteFormPage extends StatelessWidget {
  const ClienteFormPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Agregar Cliente"),
        backgroundColor: Theme.of(context).primaryColor,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Foto del cliente
              Center(
                child: GestureDetector(
                  onTap: () {
                    // Aquí puedes abrir un picker de imágenes
                  },
                  child: CircleAvatar(
                    radius: 45,
                    backgroundColor: Colors.grey[300],
                    child: const Icon(
                      Icons.camera_alt,
                      size: 40,
                      color: Colors.black54,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                "Toca para seleccionar foto",
                style: TextStyle(color: Colors.grey),
              ),

              const SizedBox(height: 20),

              // Campo Nombre
              TextField(
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.person),
                  labelText: "Nombre",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),

              const SizedBox(height: 15),

              // Campo Apellido
              TextField(
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.person_outline),
                  labelText: "Apellido",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),

              const SizedBox(height: 15),

              // Campo Dirección
              TextField(
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.location_on),
                  labelText: "Dirección",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),

              const SizedBox(height: 15),

              // Campo Perfil (Dropdown)
              DropdownButtonFormField<String>(
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.badge),
                  labelText: "Perfil",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                items: const [
                  DropdownMenuItem(value: "Administrador", child: Text("Administrador")),
                  DropdownMenuItem(value: "Cliente", child: Text("Cliente")),
                  DropdownMenuItem(value: "Visitante", child: Text("Visitante")),
                ],
                onChanged: (value) {
                  // Aquí manejas el perfil seleccionado
                },
              ),

              const SizedBox(height: 15),

              // Campo Estado (Dropdown)
              DropdownButtonFormField<String>(
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.flag),
                  labelText: "Estado",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                items: const [
                  DropdownMenuItem(value: "Activo", child: Text("Activo")),
                  DropdownMenuItem(value: "Inactivo", child: Text("Inactivo")),
                ],
                onChanged: (value) {
                  // Aquí manejas el estado seleccionado
                },
              ),

              const SizedBox(height: 25),

              // Botones
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                    onPressed: () {
                      // Guardar cliente
                    },
                    child: const Text("Agregar"),
                  ),
                  OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text("Cancelar"),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
