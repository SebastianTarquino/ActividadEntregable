import 'package:flutter/material.dart';
import '../../widgets/appbar.dart';

class UserScreen extends StatelessWidget {
  final String username;
  final String password;

  const UserScreen({
    super.key,
    required this.username,
    required this.password,
  });

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
          SelectableText(value),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:
          const CustomAppBar(title: 'Perfil de usuario', showBackButton: true),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Center(
              child: CircleAvatar(
                radius: 60,
                backgroundColor: Colors.blue,
                child: Icon(Icons.person, size: 70, color: Colors.white),
              ),
            ),
            const SizedBox(height: 30),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    _buildInfoRow('Usuario:', username),
                    const SizedBox(height: 15),
                    _buildInfoRow('Email:', username), // Asumiendo que el username es el email
                    const SizedBox(height: 15),
                    _buildInfoRow('Contraseña:',
                        '${'*' * password.length} (${password.length} caracteres)'),
                    const SizedBox(height: 15),
                    _buildInfoRow('Estado:', 'Activo'),
                    const SizedBox(height: 15),
                    _buildInfoRow('Último acceso:', '${DateTime.now().toString().substring(0, 10)}'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Mostrar datos en consola
                print('Datos del usuario:');
                print('Usuario: $username');
                print('Contraseña: $password');
                
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Datos mostrados en consola')),
                );
              },
              child: const Text('Mostrar datos en consola'),
            ),
          ],
        ),
      ),
    );
  }
}