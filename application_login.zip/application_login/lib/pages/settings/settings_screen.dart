import 'package:flutter/material.dart';
import '../../widgets/appbar.dart';
import 'change_email.dart';
import 'change_password.dart';
import 'change_theme.dart';
import 'change_language.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(title: 'Configuración', showBackButton: true),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [ 
            const Text(
              'Preferencias de la aplicación',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView(
                children: [
                  _buildSectionTitle('Cuenta'),
                  _buildSettingsItem(
                    context,
                    Icons.email,
                    'Cambiar correo electrónico',
                    'Actualiza tu dirección de correo',
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const ChangeEmailScreen()),
                      );
                    },
                  ),
                  _buildSettingsItem(
                    context,
                    Icons.lock,
                    'Cambiar contraseña',
                    'Protege tu cuenta con una nueva contraseña',
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const ChangePasswordScreen()),
                      );
                    },
                  ),
                  const SizedBox(height: 16),
                  _buildSectionTitle('Apariencia'),
                  _buildSettingsItem(
                    context,
                    Icons.color_lens,
                    'Tema de la aplicación',
                    'Personaliza colores y estilo visual',
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const ChangeThemeScreen()),
                      );
                    },
                  ),
                  _buildSettingsItem(
                    context,
                    Icons.language,
                    'Idioma',
                    'Selecciona tu idioma preferido',
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const ChangeLanguageScreen()),
                      );
                    },
                  ),
                  const SizedBox(height: 16),
                  _buildSectionTitle('Información'),
                  _buildInfoItem(
                    Icons.info,
                    'Versión de la aplicación',
                    '1.0.0',
                  ),
                  _buildInfoItem(
                    Icons.phone,
                    'Soporte técnico',
                    'soporte@miapp.com',
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w600,
          color: Colors.grey,
        ),
      ),
    );
  }

  Widget _buildSettingsItem(BuildContext context, IconData icon, String title, String subtitle, VoidCallback onTap) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(icon, color: Theme.of(context).primaryColor),
        title: Text(title),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        onTap: onTap,
      ),
    );
  }

  Widget _buildInfoItem(IconData icon, String title, String value) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(icon, color: Colors.grey),
        title: Text(title),
        trailing: Text(value, style: const TextStyle(color: Colors.grey)),
      ),
    );
  }
}